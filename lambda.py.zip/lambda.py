def lambdaHandler(event, context):
    print('Hello World')
